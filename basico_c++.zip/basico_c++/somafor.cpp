#include<iostream>
#include<locale.h>
using namespace std;

int main(){
	int soma = 0, i=1,n;
	cout<<"digite um numero ";
	cin >> n;
	for(int i = 1;i<=n;i++){
		soma= soma +i;
		
	}
cout<<"a soma de todos os numeros e de "<<soma<<endl;
return 0 ;
	
	
}
